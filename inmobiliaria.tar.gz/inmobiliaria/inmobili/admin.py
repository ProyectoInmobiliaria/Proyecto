from django.contrib import admin
from inmobili.models import *
# Register your models here.
admin.site.register(Casa)
admin.site.register(Perfil)
admin.site.register(Comment)
admin.site.register(Image)
admin.site.register(Fav)